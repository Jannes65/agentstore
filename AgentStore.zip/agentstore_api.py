from fastapi import FastAPI, HTTPException, Query, Depends
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Optional
import uvicorn
import os
from pydantic import BaseModel
from sqlalchemy.orm import Session

from agentstore_schema import Category
from agentstore_adapter import LangChainAdapter, CrewAIAdapter, AutoGenAdapter
from agentstore_trust import PermissionScope, TrustScore, ExecutionLog
from agentstore_marketplace import Marketplace, Listing
from agentstore_database import init_db, get_db, save_agent, get_agent as get_agent_db, get_all_agents, save_execution_log, add_to_waitlist, Builder
from agentstore_builder_api import router as builder_router
from agentstore_payments import create_invoice, check_payment
from agentstore_ledger import credit_balance, get_balance

app = FastAPI(title="AgentStore API")
app.include_router(builder_router)

# Add CORS middleware to allow the UI to fetch agents
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For local testing, allow all
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global marketplace instance
marketplace = Marketplace()

# Waitlist Request Model
class WaitlistEntry(BaseModel):
    email: str
    name: str

# Request body model for running an agent
class RunInput(BaseModel):
    input: str
    user_id: str = "anonymous"

class DepositRequest(BaseModel):
    user_id: str
    amount_sats: int

@app.on_event("startup")
async def startup_event():
    """Initialize database."""
    init_db()

@app.get("/agents")
async def get_agents(
    category: Optional[Category] = None, 
    verified_only: bool = Query(False),
    db: Session = Depends(get_db)
):
    """Returns all listings with optional filtering."""
    results = get_all_agents(db, category=category.value if category else None, verified_only=verified_only)
    return results

@app.get("/agents/top")
async def get_top_agents(db: Session = Depends(get_db)):
    """Returns top 5 agents by trust score."""
    from agentstore_database import Agent
    results = db.query(Agent).order_by(Agent.community_rating.desc()).limit(5).all()
    return results

@app.get("/agents/{agent_id}")
async def get_agent(agent_id: str, db: Session = Depends(get_db)):
    """Returns a single listing or 404."""
    agent = get_agent_db(db, agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent listing not found")
    return agent

@app.post("/agents/{agent_id}/run", response_model=ExecutionLog)
async def run_agent(agent_id: str, run_input: RunInput, db: Session = Depends(get_db)):
    """Executes an agent securely with full payment flow."""
    from agentstore_marketplace import Marketplace
    marketplace = Marketplace()
    
    try:
        log = marketplace.run_agent(agent_id, run_input.input, user_id=run_input.user_id)
        
        # Save log to DB
        save_execution_log(db, {
            "agent_id": agent_id,
            "input_str": run_input.input,
            "output": log.output,
            "permissions_used": log.permissions_used
        })
        
        return log
    except ValueError as e:
        if "Insufficient balance" in str(e):
            raise HTTPException(status_code=402, detail=str(e))
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/agents/{agent_id}/balance")
async def get_agent_balance_api(agent_id: str):
    """Returns agent's accumulated earnings"""
    from agentstore_ledger import get_agent_balance
    balance = get_agent_balance(agent_id)
    return {"agent_id": agent_id, "balance_sats": balance}

@app.get("/builders/{builder_id}/earnings")
async def get_builder_earnings(builder_id: str, db: Session = Depends(get_db)):
    """Sum of all agent balances for that builder"""
    builder = db.query(Builder).filter(Builder.id == builder_id).first()
    if not builder:
        raise HTTPException(status_code=404, detail="Builder not found")
    
    from agentstore_ledger import get_agent_balance
    total_earnings = 0
    agent_balances = {}
    
    for agent in builder.agents:
        balance = get_agent_balance(agent.id)
        total_earnings += balance
        agent_balances[agent.id] = balance
        
    return {
        "builder_id": builder_id,
        "total_earnings_sats": total_earnings,
        "agent_breakdown": agent_balances
    }

@app.post("/waitlist")
async def join_waitlist(entry: WaitlistEntry, db: Session = Depends(get_db)):
    """Adds a new user to the waitlist."""
    try:
        add_to_waitlist(db, entry.model_dump())
        return {"message": "Joined waitlist successfully"}
    except Exception as e:
        raise HTTPException(status_code=400, detail="Email already exists or invalid data")

@app.post("/chat")
async def chat(request: dict):
    import httpx
    async with httpx.AsyncClient() as client:
        response = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": os.environ.get("ANTHROPIC_API_KEY"),
                "anthropic-version": "2023-06-01",
                "content-type": "application/json"
            },
            json=request,
            timeout=30.0
        )
        result = response.json()
        print(f"Anthropic response status: {response.status_code}")
        print(f"Anthropic response: {result}")
        return result

@app.post("/payments/deposit")
async def deposit(req: DepositRequest):
    """Creates invoice, returns paymentRequest and engineInvoiceRef"""
    try:
        memo = f"Deposit for user {req.user_id}"
        # We use user_id as external_ref to identify the user on callback/status check
        invoice = await create_invoice(req.amount_sats, memo, req.user_id)
        return {
            "paymentRequest": invoice["payment_request"],
            "engineInvoiceRef": invoice["engine_invoice_ref"]
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/payments/status/{engine_invoice_ref}")
async def payment_status(engine_invoice_ref: str, user_id: str, amount_sats: int):
    """Checks payment, if paid credits user balance"""
    try:
        status = await check_payment(engine_invoice_ref)
        if status.get("status") == "paid":
            credit_balance(user_id, amount_sats)
            return {"status": "paid", "balance_updated": True}
        return {"status": status.get("status", "pending")}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/payments/balance/{user_id}")
async def read_balance(user_id: str):
    """Returns current balance"""
    balance = get_balance(user_id)
    return {"user_id": user_id, "balance_sats": balance}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
